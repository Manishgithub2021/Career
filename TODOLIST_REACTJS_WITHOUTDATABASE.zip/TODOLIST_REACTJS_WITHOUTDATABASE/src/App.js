import Card from "./components/Card";
import classes from './components/Card.module.css';
import Form from "./components/Form";
import React,{useState} from "react";



const App=(props)=>{
    const[dolist,dolisthandler]=useState([]);
    
       const SubmitFormHandler=(event)=>{

        
        event.preventDefault();
        
        
        
        dolisthandler((prevState)=>[...prevState,event.target.children[0].value]);
        

    };
    
function removethisitem(item){
    console.log(item+"   to be delted");
    dolisthandler((prevState)=>prevState.filter((name)=>{
        return name!==item;
    }));
}
    return (
       
        <div>
             
            <div className={classes.box}>
            <h1 className={classes.heading}>TO-DOLIST</h1>
            <Form onSubmit={SubmitFormHandler} ></Form>
            </div>
        <div className={classes.backgroundbox} >
            {dolist.map((item)=><Card key={Math.random()} list={item} onDelete={removethisitem} />)}
        </div>
        </div>
    );
};
export default App;