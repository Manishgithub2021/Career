import Button from "./Button";

const Form=(props)=>{
    return(
        <div>
        <form onSubmit={props.onSubmit}>
            
            <input type="text" id="list" placeholder="Enter your listName" ></input>
           <Button></Button>
           
        </form>
        
       </div>
    );
};
export default Form;