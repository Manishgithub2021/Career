
import classes from './Card.module.css';

import React from 'react';
const Card=(props)=>{
    function handleclick(){
        props.onDelete(props.list);
    }
    return (
        <div className={classes.box}>
            <div className={classes.list}>
                {props.list}

            </div>
            <button type="button" className={classes.delbutton} onClick={handleclick}>Delete</button>
        </div>
    );
};
export default Card;