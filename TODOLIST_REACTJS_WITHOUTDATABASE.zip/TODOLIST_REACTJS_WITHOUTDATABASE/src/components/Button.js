import classes  from './Card.module.css';
const Button=(props)=>{
    return(
        <button type="submit" className={classes.button}>Add List</button>
    );
};
export default Button;