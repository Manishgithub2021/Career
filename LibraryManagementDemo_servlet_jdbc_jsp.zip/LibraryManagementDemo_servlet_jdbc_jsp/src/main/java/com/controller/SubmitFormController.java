package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;  

@WebServlet("/SubmitFormController")
public class SubmitFormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SubmitFormController() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=(String) request.getParameter("studentname");
		String bookname=(String) request.getParameter("book");
		
		String dor=(String) request.getParameter("dor");
		System.out.println(dor+ ""+dor.length());
		String id= request.getParameter("id");
		int id1=Integer.parseInt(id);
		

		 
			try {
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))(CONNECT_DATA=(SID=xe)))","INVENTORY1","INVENTORY1");  
			PreparedStatement st = con
                    .prepareStatement("DELETE FROM LIBRARY WHERE ID=?");
            st.setInt(1, Integer.valueOf(request.getParameter("id")));
            int rowafffected =st.executeUpdate();
//			PreparedStatement st = con
//                   .prepareStatement("update library set DATE_OF_RETURN=? where ID=?");
//  
//            // For the first parameter,
//            // get the data using request object
//            // sets the data to st pointer
//			st.setString(1, request.getParameter("dor"));
//            st.setInt(2, Integer.valueOf(request.getParameter("id")));
  
            // Same for second parameter
            
            
            // Execute the insert command using executeUpdate()
            // to make changes in database
            
            if(rowafffected>0) {
            	System.out.println(rowafffected+"Row deleted");
                request.setAttribute("id", Integer.valueOf(request.getParameter("id")));
                request.setAttribute("name",(request.getParameter("studentname")));
                request.setAttribute("book",(request.getParameter("book")));
                
//                if(rowafffected1>0) {
//                	System.out.println(rowafffected1+" :ROWS DELETED SUCCESSFULLY");
//                	
//                }
                request.getRequestDispatcher("DisplayStudentInfo.jsp").forward(request, response);
                }
                else {
                	
                	request.setAttribute("error","No record found for this student");
                     request.getRequestDispatcher("Error.jsp").forward(request, response);}
            st.close();
			con.close();
			  
			}catch(Exception e)  {
				request.setAttribute("error",e);
                request.getRequestDispatcher("Error.jsp").forward(request, response);
			}
		}
			
		
		
	}


/*CREATE TABLE LIBRARY(
ID NUMBER(4) PRIMARY KEY,
STUDENTNAME VARCHAR2(50) NOT NULL,
BOOKS VARCHAR2(100) NOT NULL,
DATE_OF_ISSUE VARCHAR2(50) NOT NULL,
DATE_OF_RETURN VARCHAR2(50),
LATE_FINE NUMBER(4));
SELECT * FROM LIBRARY;*/