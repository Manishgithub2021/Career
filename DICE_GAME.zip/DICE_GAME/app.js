var num1;
var num2;
var player1movecount=0;
var player2movecount=0;
var whosemove="first";
alert("Rules\n Game start with player1\nSo player1 will move his dice ,then player2\nWinner will be one, whose dice face number is more\nDraw if equal");

function player1move(){

  num1=Math.trunc(Math.random()*6+1);
  player1movecount=player1movecount+1;
  dice=`dice${num1}.png`;
  document.getElementById('player1img').src=dice;
  document.getElementById("player1img").classList.remove("hidden");

  //console.log(player1movecount);
  document.getElementById('first').style.color = 'white';
document.getElementById('second').style.color = 'red';
}

function player2move(){
num2=Math.trunc(Math.random()*6+1);
dice=`dice${num2}.png`;
document.getElementById('player2img').src=dice;
  player2movecount=player2movecount+1;
  document.getElementById("player2img").classList.remove("hidden");

  //console.log(player2movecount);
  winner();
document.getElementById('first').style.color = 'red';
document.getElementById('second').style.color = 'white';
}

function winner(){
  if(player1movecount!=0 && player2movecount!=0){
    if(player1movecount===player2movecount){
                    if(num1>num2){
                       console.log(`num1:${num1}>num2:${num2}, num1 is winner`);
                       document.getElementById("flag1").classList.remove("hidden");
                       setTimeout(function(){ document.getElementById("flag1").classList.add("hidden");
                     document.getElementById("player1img").classList.add("hidden");
                   document.getElementById("player2img").classList.add("hidden"); }, 1000);
                    }
                    else if (num1<num2) {
                      console.log(`num1:${num1}<num2:${num2}, num2 is winner`);
                      document.getElementById("flag2").classList.remove("hidden");
                      setTimeout(function(){ document.getElementById("flag2").classList.add("hidden");
                      document.getElementById("player1img").classList.add("hidden");
                    document.getElementById("player2img").classList.add("hidden"); }, 1000);

                    }
                    else{
                      console.log(`num1:${num1}=num2:${num2}   Draw`);
                      document.getElementById("draw").classList.remove("hidden");
                      setTimeout(function(){ document.getElementById("draw").classList.add("hidden");
                      document.getElementById("player1img").classList.add("hidden");
                    document.getElementById("player2img").classList.add("hidden"); }, 1000);
                    }
    }
  };

}
