
import AnimalShow from './AnimalShow';
import './App.css';
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [animal,setanimal]=useState('');
    const [arr,setarr]=useState([]);
    function setanimalhandler(event){
      setanimal(event.target.value);
    }
    function add(){
      const newarr=[...arr,animal];
      setarr(newarr);
      setanimal('');
    }
const animalshowarr=arr.map(mapfunction);
function mapfunction(num){
  return <AnimalShow image={num}></AnimalShow>
}
  return (
  
    <div>
     <div id="navbarr">
     <input value={animal} onChange={setanimalhandler} placeholder='ENTER ANIMAL NAME'></input>
     <br></br>
     <button onClick={add}>Add</button>
     </div>
     <div class="grid-container">
     {animalshowarr}
     </div>
    </div>
  );
}

export default App;
