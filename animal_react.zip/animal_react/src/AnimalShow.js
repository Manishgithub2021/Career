import './AnimalShow.css';
import bird from './svg/bird.svg';
import cat from './svg/cat.svg';

import cow from './svg/cow.svg';

import dog from './svg/dog.svg';

import gator from './svg/gator.svg';

import heartt from './svg/heart.svg';

import horse from './svg/horse.svg';
import { useState } from 'react';


function AnimalShow(props){

    const maparr={
        bird,
        cat,
        cow,
        dog,
        gator,
        horse,
        heartt
    }
    const [like,setlike]=useState(0);
    const [dislike,setdislike]=useState(0);
    const [heart,setheart]=useState(0);
    function updatelike(){
        setlike(like+1);
    }
    function updatedislike(){
        setdislike(dislike+1);
    }
    function updateheart(){
        setheart(heart+1);
    }
    return (
        <div class="grid-item">
  
           <img src={maparr[props.image]}></img>
           <br></br>
           <br></br>
           <span><img id="heartimage" onClick={updateheart} src={heartt}></img>{heart}</span>
        </div>
        
    );
}
export default AnimalShow;