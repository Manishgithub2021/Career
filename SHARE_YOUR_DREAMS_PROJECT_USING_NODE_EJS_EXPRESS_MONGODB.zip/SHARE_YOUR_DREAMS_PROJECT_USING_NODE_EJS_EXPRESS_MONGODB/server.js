const express=require('express');
const ejs=require('ejs');
const mongoose=require('mongoose');
const bodyparser=require('body-parser');
const app=express();
app.use(bodyparser.urlencoded({extended:true}));
app.use(express.static("public"));
app.set('view engine','ejs');
mongoose.connect('mongodb://localhost:27017/dreamers');
const dreamerSchema=mongoose.Schema({
  email:{
    type:String,
    required:true
  },
  password:{
    type:String,
    required:true
  }
});
const dreamPostSchema=mongoose.Schema({
  dreamPost:{
    type:String,
    required:true
  }

});
const dreamermodel=mongoose.model("dream",dreamerSchema);
const dreamPost=mongoose.model("dreampost",dreamPostSchema);

let alldreams=[]
app.post("/post-dreams",function(req,res){
  const postdone=req.body.postdreams;
  const newpost=dreamPost({
    dreamPost:postdone
  });
  newpost.save();
  res.redirect("/SeeAllDreams");
});
app.post("/SeeAllDreams",function(req,res){
  alldreams=[];
  dreamPost.find({},function(err,result){
    if(err){
      console.log(err);
    }
    else{
      for(let i=0;i<result.length;i++){
        alldreams.push(result[i].dreamPost);
      }
      res.render("seealldreams",{alldreams:alldreams});
    }

  });

});
// app.get("/SeeAllDreams",function(req,res){
//   alldreams=[];
//   dreamPost.find({},function(err,result){
//     if(err){
//       console.log(err);
//     }
//     else{
//       for(let i=0;i<result.length;i++){
//         alldreams.push(result[i].dreamPost);
//       }
//       res.render("seealldreams",{alldreams:alldreams});
//     }
//
//   });
//
// });
app.get("/",function(req,res){
  res.render("index");
});
app.post("/login",function(req,res){

  res.render("login");

});
app.get("/login",function(req,res){
  res.render("login");

});
app.post("/register",function(req,res){
  res.render("register");

});
app.post("/logout",function(req,res){
  res.redirect("/");
})
app.post("/logindata",function(req,res){
  const emailid=req.body.email;
  const password=req.body.password;
  dreamermodel.findOne({email:emailid},function(err,result){
    if(err){
      console.log(err);
    }
    else{
      if(result){


        res.render("dreams");
      }
      else{
        res.render("error",{message:"NOT A REGISTER USER"});
        //res.render("register");
      }
    }});

  });




app.post("/registerdata",function(req,res){
  const emailid=req.body.email;
  const password=req.body.password;
dreamermodel.findOne({email:emailid},function(err,result){
  if(err){
    console.log(err);
  }
  else{
    if(result)
    res.redirect("/login");
    else{
      const newUser=new dreamermodel({
        email:emailid,
        password:password
      });
      newUser.save(function(err,result){
        if(err){
          res.render("error",{message:"REGISTRATION UNSUCCESSFUL ,TRY AFTER SOME TIME"});
        }
        else{
          res.render("dreams.ejs");
        }
      });
    }
  }

});



});
app.listen(3000,function(req,res){
  console.log("SERVER IS UP AND LISTENING");
});
