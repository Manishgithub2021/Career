

function myFunction()
 {
  setInterval(function(){
    var d = new Date(); // for now
    var hrs=d.getHours(); // => 9
    if(hrs<10){
      hrs=`0${hrs}`
    }

    var min=d.getMinutes(); // =>  30
    if(min<10){
      min=`0${min}`
    }
    var sec=d.getSeconds(); // => 51
    if(sec<10){
      sec=`0${sec}`
    }
  document.getElementsByClassName("timer")[0].innerText=`${hrs}:${min}:${sec}`;

}, 1000)};
myFunction();
