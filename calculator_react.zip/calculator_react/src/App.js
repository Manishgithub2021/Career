import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {
  const [inputvalue, setinputvalue]=useState('');
  function update(event){
   // console.log(event.target.value);
    setinputvalue(inputvalue+event.target.value);
    //console.log(inputvalue);
  }
  function deleted(){
   // console.log('delte called');
    let valueofinput=inputvalue.toString();
    let ssubstring=valueofinput.substring(0,valueofinput.length-1);
   // console.log(ssubstring);
    setinputvalue(ssubstring);
  }
  function cancel(){
    setinputvalue('');
  }
  function evaluate(){
    try{
    let output=eval(inputvalue);
    let stringvalue=output.toString();
    setinputvalue(eval(stringvalue));
    }
    catch(e){
      setinputvalue('something went wrong !! Cancel and try again');
    }
  }
  return (
    <div className="box">
      <div>
        <input value={inputvalue}></input>
      </div>
      <div className="buttons">
      <button onClick={update} value="7">7</button>
<button onClick={update} value="8">8</button>
<button onClick={update} value="9">9</button>
<button onClick={update} value="/">/</button>

<button onClick={update} value="4">4</button>
<button onClick={update} value="5">5</button>
<button onClick={update} value="6">6</button>
<button onClick={update} value="*">x</button>

<button onClick={update} value="1">1</button>
<button onClick={update}value="2">2</button>
<button onClick={update} value="3">3</button>
<button onClick={update} value="-">-</button>

<button onClick={update} value="0">0</button>
<button onClick={update} value=".">.</button>
<button onClick={update} value="+">+</button>
<button onClick={evaluate} value="=">=</button>

<button onClick={deleted}>del</button>
<button onClick={cancel}>Cancel</button>
<button onClick={update} value="(">(</button>
<button onClick={update} value=")">)</button>

      </div>
    </div>
  );
}

export default App;
